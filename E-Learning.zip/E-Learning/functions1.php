<?php
session_start();

// initializing variables
$nic = "";
$course = "";
$year = "";
$username = "";
$email    = "";
$usertype ="";
//$password = "";
$errors = array(); 
$error="";

// connect to the database
//$db = mysqli_connect('localhost', 'root', '', 'e-learn');
include('DB.php');
// REGISTER USER

if ($_SERVER["REQUEST_METHOD"] == "POST")
  {
	if (isset($_POST['register_btn']))
	    { // ***********
	  // receive all input values from the form
    $nic = mysqli_real_escape_string($db, $_POST['nic']);
	$course = mysqli_real_escape_string($db, $_POST['course']);
	$year = mysqli_real_escape_string($db, $_POST['year']);
    $username = mysqli_real_escape_string($db, $_POST['username']);
    $email = mysqli_real_escape_string($db, $_POST['email']);
    $password = mysqli_real_escape_string($db, $_POST['password']);
	
			if (!empty($_POST['nic'])) { $nic = mysqli_real_escape_string($db,trim($_POST['nic']));}
			if (!empty($_POST['course'])) {$course = mysqli_real_escape_string($db,trim($_POST['course']));}
			if (!empty($_POST['year'])) {$year = mysqli_real_escape_string($db,trim($_POST['year']));}
			if (!empty($_POST['username'])) { $username = mysqli_real_escape_string($db,trim($_POST['username']));}
			if (!empty($_POST['email'])) { $email = mysqli_real_escape_string($db,trim($_POST['email']));}
			if (!empty($_POST['password'])) { $password = mysqli_real_escape_string($db,trim($_POST['password']));}

		

				if ($nic != ''){
					$querynic="SELECT * FROM user WHERE nic='$nic' and year='$year'";
					$querynic = mysqli_query($db, $querynic);
					if(mysqli_num_rows($querynic) > 0){
						$error="NIC Already Registered for this Year";
					}else{
						// insert data in user
						$sql = "INSERT INTO `user`( nic, courseid, year, username, email, password)	
							VALUES ('".$nic."', '".$course ."', '".$year ."', '".$username."', '".$email."', '".$password."')";
						if (!mysqli_query($db, $sql))
							{
								
							}
						else  // Insert successful
						  {
							// Store student id in session variable
						
							header('Location: Login.php');
						}

					}
						
				}
		}
	}

// LOGIN USER

/*if (isset($_POST['submit']))
{
	$MyUsername = mysqli_real_escape_string($db,trim($_POST['username']));
	$MyPassword = mysqli_real_escape_string($db,trim($_POST['password']));
	

	$sqlSelect = "SELECT * FROM user WHERE Username= '".$MyUsername."'";
	$result = mysqli_query($db, $sqlSelect);

	if (mysqli_num_rows($result) > 0)
	{
		while($row = mysqli_fetch_assoc($result))
		{
			$username= $row["Username"];
			$password = $row["Password"];
			$usertype = $row["User_Type"];
		
		}
	}else
	{
		$username = "";
		$password = "";
		$usertype = "";
	

	}

	if($MyUsername == $username && $MyPassword == $password && $usertype == "Student")
		{

	

			$_SESSION['username']= $username;
		


					header('Location:E_Student/Student_Home.php');

		}
	else
			if($MyUsername == $username && $MyPassword == $password && $User == "A")
		{

			$_SESSION['id']= $Id;

			$_SESSION['username']= $username;
			$_SESSION['school']= $School;
			$_SESSION['email']=$email;
			$_SESSION['passkey']=$passkey;

					header('Location: StudAffairs.php');

		}
}*/

?>

