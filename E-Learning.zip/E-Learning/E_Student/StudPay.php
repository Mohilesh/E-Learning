<?php 
session_cache_limiter('public');
session_start();
$Id = $_SESSION['id'];
include('paymentfunctions.php');
$error = "";
  @$error=$_GET['msg'];
  if ($error=='success'){
  $error= "Successfully Inserted";
  }  

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">

<title>E-Learn</title>
	
	
	<!-- main css -->
	<link rel="stylesheet" href="../css/mystyle.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
  


</head>

<body >

    <input type="checkbox" id="check">
    <!--header area start-->
    <header>
      
      <div class="left_area">
        <h3>E<span>LEARN</span></h3>
      </div>
      <div class="right_area">
      <div align="center">Hi - <?php echo $_SESSION['username']; ?></div>
        <a href="../Logout.php" class="logout_btn">Logout</a>
      </div>
    </header>
    <!--header area end-->
    <!--sidebar start-->
    <div class="sidebar">
      <center>
        <h2>Student</h2>
      </center>
      <a href="Student_Home.php"><i class="fas fa-desktop"></i><span>Dashboard </span></a>
      <a href="StudModule.php"><i class="fas fa-sticky-note"></i><span>Module</span></a>
      <a href="StudAssignment.php"><i class="fas fa-tasks"></i><span>Assignment</span></a>
      <a href="Blog.php"><i class="fas fa-blog"></i><span>Blog</span></a>
      <a href="Stud_NE.php"><i class="fas fa-calendar-check"></i><span>Events</span></a>
      <a href="Chat/index.php"><i class="fas fa-comment-alt"></i><span>Chat</span></a>
      <a href="StudPay.php"><i class="fas fa-money-bill-wave"></i><span>Payment</span></a>
    </div>
    <!--sidebar end-->

    <div class="payment"  style="padding-top:100px;" >
    <div class="header">
              <h2>Payment</h2>
              <div  style= "colour:red">
              <?php
                echo'<span style="color:green ; font-weight: bold;">' .$error. '</span>';
              ?>
            </div>
            </div>
		
        <form method="post"  action="StudPay.php" class="pay">
            

            <div class="input-group">
              <label>Year</label>
              <select name="year" required id="year" >
                <option value="0">Select Year</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
              </select>
            </div>

            <div class="input-group">
                <label>Reference Code</label>
                <input type="text" name="reference" required placeholder="Enter Reference Code">
            </div>

            <div class="input-group" >
                    <label>Payment Method</label>
                    <select name="payment" id="paymentmethod" >
                        <option value="0">Select Payment Method</option>
                        <option value="cash">Cash</option>
                        <option value="JI">Juice or Internet Banking</option>
                        <option value="BT">Bank Transfer</option>
                    </select>
                </div>
            
        
            
            <div class="input-group">
                <button type="submit"  class="btn" name="payment_btn">Pay</button>
            </div>
            
        </form>


	</div>

  </body>

</html>





