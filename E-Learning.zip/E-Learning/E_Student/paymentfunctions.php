<?php
    

    // initializing variables
    $year="";
    $reference    = "";
    $payment ="";
    $errors = array(); 
    
    // connect to the database
    //$db = mysqli_connect('localhost', 'root', '', 'e-learn');
    include('DB.php');


    if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        if (isset($_POST['payment_btn']))
            { // ***********
        // receive all input values from the form
        
        $year = mysqli_real_escape_string($db, $_POST['year']);
        $reference = mysqli_real_escape_string($db, $_POST['reference']);
        $payment = mysqli_real_escape_string($db, $_POST['payment']);
        
                
                if (!empty($_POST['year'])) {$year = mysqli_real_escape_string($db,trim($_POST['year']));}
                if (!empty($_POST['reference'])) { $reference = mysqli_real_escape_string($db,trim($_POST['reference']));}
                if (!empty($_POST['payment'])) { $payment = mysqli_real_escape_string($db,trim($_POST['payment']));}

            

                    if ($year != ''){
                            // insert data in user
                            $sql = "INSERT INTO `payment`(year, referenceCode, modePayment)	
                                VALUES ('".$year."', '".$reference."', '".$payment."')";
                            if (!mysqli_query($db, $sql))
                                {
                                    //die('error inserting new record');
                                    die(mysqli_error($db));
                                }
                            else  // Insert successful
                            {
                                // Store student id in session variable
                            
                                header('Location: StudPay.php');
                            }
                    }
        }
	}

?>