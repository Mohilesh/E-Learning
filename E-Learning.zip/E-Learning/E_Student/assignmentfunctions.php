<?php
    include "DB.php";// Using database connection file here
    $module = "";
    

    if ($_SERVER["REQUEST_METHOD"] == "POST")
    {

        if (isset($_POST['assign_btn'])&& isset($_FILES['bcfile'])) { // if save button on the form is clicked
            // receive all input values from the form
            $module = mysqli_real_escape_string($db, $_POST['module']);
    
            if (($_FILES['bcfile']['name']!=""))
            {
            // Where the file is going to be stored
            $file = $_FILES['bcfile']['name'];
            $size = $_FILES['bcfile']['size'];
           
             $path = pathinfo($file);
             $filename = $path['filename'];
             $size= number_format($size);
             $temp_name = $_FILES['bcfile']['tmp_name'];
             $target_dir = "$destination/";
            }
            // Uploads files
            
            $destination = "../docs/assign/$module";
                
                if (!is_dir( $destination ) ) // If directory does not exist, create it.
                 {
                    mkdir( "$destination" );
             }
             $queryassign="SELECT * FROM assignment WHERE file='$file'";
                            $queryassign = mysqli_query($db, $queryassign);
                            if(mysqli_num_rows($queryassign) > 0){
                                header('location:studassignment.php?msg=error');
                            }else{
                    $sql = "INSERT INTO assignment (moduleid,file,size,userid) VALUES ('$module','$file','$size','$Id')";
             if (mysqli_query($db, $sql)) {
                
             
             
             
             $path_filename_ext = $target_dir.$file;
             move_uploaded_file($temp_name,$path_filename_ext);
        
             
             }
             header('location:studassignment.php?msg=success');
            }      
        }
    }


?>