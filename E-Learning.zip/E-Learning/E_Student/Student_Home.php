<?php 

  session_cache_limiter('public');
  session_start();
  $Id = $_SESSION['id'];

  
  include('DB.php');
?>
<!doctype html>
<html>
<head>

<style>
#calendar {
        width: 700px;
        margin: 0 auto;
    }
</style>

<script>

    $(document).ready(function () {
        var calendar = $('#calendar').fullCalendar({
            editable: true,
            events: "fetch-event.php",
            displayEventTime: false,
            eventRender: function (event, element, view) {
                if (event.allDay === 'true') {
                    event.allDay = true;
                } else {
                    event.allDay = false;
                }
            },

        });
    });

    
  </script>



<meta charset="utf-8">

<title>E-Learn</title>
	
	
	<!-- main css -->
	<link rel="stylesheet" href="../css/mystyle.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
  <link rel="stylesheet" href="fullcalendar/fullcalendar.min.css" />
  <script src="fullcalendar/lib/jquery.min.js"></script>
  <script src="fullcalendar/lib/moment.min.js"></script>
  <script src="fullcalendar/fullcalendar.min.js"></script>
</head>

<body class="studlogin">

    <input type="checkbox" id="check">
    <!--header area start-->
    <header>
      
      <div class="left_area">
        <h3>E<span>LEARN</span></h3>
      </div>
      <div class="right_area">
         <div align="center">Hi - <?php echo $_SESSION['username']; ?></div>
        <a href="../Logout.php" class="logout_btn">Logout</a>
      </div>
    </header>
    <!--header area end-->
    <!--sidebar start-->
    <div class="sidebar">
      <center>
        <h2>Student</h2>
      </center>
      <a href="Student_Home.php"><i class="fas fa-desktop"></i><span>Dashboard </span></a>
      <a href="StudModule.php"><i class="fas fa-sticky-note"></i><span>Module</span></a>
      <a href="StudAssignment.php"><i class="fas fa-tasks"></i><span>Assignment</span></a>
      <a href="Blog.php"><i class="fas fa-blog"></i><span>Blog</span></a>
      <a href="Stud_NE.php"><i class="fas fa-calendar-check"></i><span>Events</span></a>
      <a href="Chat/index.php"><i class="fas fa-comment-alt"></i><span>Chat</span></a>
      <a href="StudPay.php"><i class="fas fa-money-bill-wave"></i><span>Payment</span></a>
    </div>
    <!--sidebar end-->

    <div class="content">

      <div class="home">
        <div class="main">
        <a href="StudModule.php">Module for This Year</a>
        </div>

      </div>


		
	  </div>

  </body>

</html>