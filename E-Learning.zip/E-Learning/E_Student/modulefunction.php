<?php  
 include("DB.php");
 $query ="SELECT * FROM module" ;  
 $result = mysqli_query($db, $query);  
?>