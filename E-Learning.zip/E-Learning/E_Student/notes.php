<?php
session_cache_limiter('public');
session_start();
$module = $_GET['id'] ;

include("DB.php");
$dir = "../docs/notes/$module";
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">

<title>E-Learn</title>
	
	
	<!-- main css -->

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
  <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>  
  <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>  
</head>

<body >

    
    

    <div class="content">
    
    
       
      <div class="col-md-9" style="padding-top:100px; padding-left: 150px">
                
                    
                
                  
                <div class="table-responsive" >  
                    <table class="table table-borderless" id="applTable">
                         <tr>
               
                    <th>File</th>
                    <th>Video</th>
                    
                         
                         </tr>
                         <?php

                    
                              
                                   
                              if (is_dir($dir)){
                                   if ($dh = opendir($dir)){
                                        
                                        while (($file = readdir($dh)) !== false){
                                        
                                        
                                        $querynotes="SELECT * FROM notes WHERE filename='$file'";

                                        $querynotes = mysqli_query($db, $querynotes);
                                        if(mysqli_num_rows($querynotes) > 0)
                          
                          {
                                        $querynotesrow = mysqli_fetch_assoc($querynotes) ;   
                                        
                                        $filename=$querynotesrow['videolink'];
                          
                                        echo "<tr>";
                                        echo "<td> <a href='$dir/$file'  target='_blank'>$file</a> </td>";
                                        echo "<td> <a href='$filename'  target='_blank'>$filename</a> </td>";
                                        echo "</tr>";
                                   
                                        }
                                   }
                                        closedir($dh);
                                   }
                                   }
                                   
                              ?>
                    </table> 
                </div>  
            
        


      </div>





	  </div>

  </body>
  <script>  
 $(document).ready(function(){  
      $('#notes').DataTable();  
 });  
 </script>
 <script type="text/javascript">
    document.getElementById("myButton").onclick = function () {
        location.href = "StudModule.php";
    };
</script>
</html>