<?php 
  session_cache_limiter('public');
  session_start();
  $Id = $_SESSION['id'];
  include('assignmentfunctions.php');
  $error = "";
  @$error=$_GET['msg'];
  if ($error=='success'){
    $error='<span style="color:green ; font-weight: bold;"> Successfully Added </span>';
  } elseif ($error=='error'){
 
    $error='<span style="color:red ; font-weight: bold;"> Already Added </span>';
  }
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">

<title>E-Learn</title>
	
	
	<!-- main css -->
	<link rel="stylesheet" href="../css/mystyle.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
</head>

<body class="studlogin">

    <input type="checkbox" id="check">
    <!--header area start-->
    <header>
      
      <div class="left_area">
        <h3>E<span>LEARN</span></h3>
      </div>
      <div class="right_area">
      <div align="center">Hi - <?php echo $_SESSION['username']; ?></div>
        <a href="../Logout.php" class="logout_btn">Logout</a>
      </div>
    </header>
    <!--header area end-->
    <!--sidebar start-->
    <div class="sidebar">
      <center>
        <h2>Student</h2>
      </center>
      <a href="Student_Home.php"><i class="fas fa-desktop"></i><span>Dashboard </span></a>
      <a href="StudModule.php"><i class="fas fa-sticky-note"></i><span>Module</span></a>
      <a href="StudAssignment.php"><i class="fas fa-tasks"></i><span>Assignment</span></a>
      <a href="Blog.php"><i class="fas fa-blog"></i><span>Blog</span></a>
      <a href="Stud_NE.php"><i class="fas fa-calendar-check"></i><span>Events</span></a>
      <a href="Chat/index.php"><i class="fas fa-comment-alt"></i><span>Chat</span></a>
      <a href="StudPay.php"><i class="fas fa-money-bill-wave"></i><span>Payment</span></a>
    </div>
    <!--sidebar end-->

    <div class="wrapper" style="padding-top:100px;">
            <div class="header">
              <h2>Assignment</h2>
              <div  >
              <?php
                echo$error;
              ?>
            </div>
            </div>
        <form method="POST" action="StudAssignment.php" enctype="multipart/form-data">
                
            
        <div class="input-group">
			
			<label>Select Course</label>
			<select name="module" required id="course_type" >
				<option value="0">Select Module</option>
				<?php 
                $querymodule = "SELECT * from user tbu inner join course tbc on tbu.courseid=tbc.courseid  inner join module tbm on tbc.courseid = tbm.courseid where tbu.userid = '$Id'" ;  
                $querymodule = mysqli_query($db, $querymodule);
                if(mysqli_num_rows($querymodule) > 0)
                
                {
                  while ($querymodulerow = mysqli_fetch_assoc($querymodule)) { ?>
                     <option value="<?php echo $querymodulerow['moduleid']; ?>"><?php echo $querymodulerow['moduleName']; ?></option>
                  <?php }
                }
                else
                { ?>
                  <option value="0">No Module Found</option>
                <?php }
               ?>
            </select>
		</div>

            </br>
            <input type="file" name="bcfile" />
                
            <div class="input-group">
              <button type="submit" class="btn" name="assign_btn">Submit</button>
            </div>
                
        </form>
	</div>

  </body>

</html>