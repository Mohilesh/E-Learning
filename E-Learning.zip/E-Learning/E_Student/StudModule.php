<?php 
  session_cache_limiter('public');
  session_start();
  $Id = $_SESSION['id'];
  

 
 
 include("DB.php");
 $query ="SELECT * from user tbu inner join course tbc on tbu.courseid=tbc.courseid  inner join module tbm on tbc.courseid = tbm.courseid where tbu.userid = '$Id'" ;  
 $result = mysqli_query($db, $query);  

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">

<title>E-Learn</title>
	
	
	<!-- main css -->
<!--	<link rel="stylesheet" href="../css/mystyle.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
  <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>  
  <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>            
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />
</head>

<body class="studlogin">

    <input type="checkbox" id="check">
    <!--header area start-->
    <header>
      
      
    <!--sidebar end-->

    <div class="content">
    
      
       
      <div class="col-md-9" style="padding-top:100px; padding-left: 150px">
                
                    
                
                  
      <h3 align="center">Module</h3>  
      <button class="btn btn-info" id="myButton" align="right">Back </button>
                <br /> 
                <br />  
                <div class="table-responsive">  
                     <table id="employee_data" class="table table-striped table-bordered">  
                          <thead>  
                          <tr>  
                                    <td>Module Name</td>  
                                    <td>Module Code</td>  
                                    <td>Module Mode</td>  
                                    
                               </tr>  
                          </thead>  
                          <?php  
                         while($row = mysqli_fetch_assoc($result))  
                         {  ?>
                           <tr> 
                           <?php $viewResult = "notes.php?id=$row[moduleid]";?>
                           <td><a href='<?php echo $viewResult; ?> 'target='_blank'><?php echo $row['moduleName']; ?></a></td> 
                             <td><?php echo $row['moduleCode']; ?></td>
                             <td><?php echo $row['moduleMode']; ?></td>
                            
                               
                                     
                              </tr>  
                              
                           <?php
                           }
                           ?>
                     </table>  
                </div>
            
        


      </div>





	  </div>

  </body>
  <script>  
 $(document).ready(function(){  
      $('#employee_data').DataTable();  
 });  
 </script> 
 <script type="text/javascript">
    document.getElementById("myButton").onclick = function () {
        location.href = "Student_Home.php";
    };
</script>
</html>