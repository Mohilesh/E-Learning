<?php
	session_start();
	session_unset();   //--- Unset session variables.
	session_destroy(); //--- End Session we created earlier.
	
	header('Location: Login.php');
?>


<html>
	<head>
		<title></title>
	</head>
	<body>
	</body>
</html>