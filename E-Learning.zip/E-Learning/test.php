<select class="form-control" name="courseSelected">
              <option value="0">Select Course</option>
              <?php 
                $querycourse = "SELECT * FROM course ORDER BY courseid DESC";
                $querycourse = mysqli_query($db, $querycourse);
                if(mysqli_num_rows($selCoquerycourseurse) > 0)
                
                {
                  while ($querycourserow = mysqli_fetch_assoc($querycourse)) { ?>
                     <option value="<?php echo $querycourserow['courseid']; ?>"><?php echo $querycourserow['coursename']; ?></option>
                  <?php }
                }
                else
                { ?>
                  <option value="0">No Course Found</option>
                <?php }
               ?>
            </select>