<?php
session_cache_limiter('public');
session_start();

include('DB.php');
//LOGIN
if (isset($_POST['login_btn']))
{
	$Mynic = mysqli_real_escape_string($db,trim($_POST['nic']));
	$MyPassword = mysqli_real_escape_string($db,trim($_POST['password']));
	

	$sqlSelect = "SELECT * FROM user WHERE nic= '".$Mynic."' ORDER BY year ASC";
	$result = mysqli_query($db, $sqlSelect);

	if (mysqli_num_rows($result) > 0)
	{
		while($row = mysqli_fetch_assoc($result))
		{
			$nic= $row["nic"];
			$Id= $row["userid"];
			$password = $row["password"];
			$usertype = $row["user_type"];
			$username = $row["username"];
		
		}
	}else
	{
		$nic = "";
		$password = "";
		$usertype = "";
		$Id = "";
		$username = "";

	}

	if($Mynic == $nic && $MyPassword == $password && $usertype == "S")
		{
			$_SESSION["id"]= $Id;
			$_SESSION["username"]= $username;
			$_SESSION["nic"]= $nic;

					header('Location:E_Student/Stud_NE.php');
		}
	else
			if($Mynic == $nic && $MyPassword == $password && $usertype == "L")
		{

			$_SESSION["id"]= $Id;
			$_SESSION["nic"]= $nic;
			$_SESSION["username"]= $username;

					header('Location: E_Lecturer/NE.php');

		}
	else
			if($Mynic == $nic && $MyPassword == $password && $usertype == "A")
		{

			$_SESSION["id"]= $Id;
			$_SESSION["nic"]= $nic;
			

					header('Location: E_Admin/Admin_Home.php');

		}
}

