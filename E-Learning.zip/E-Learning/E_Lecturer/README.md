# PHP-File-Upload-Example
An example that demonstrates the basics of file upload in PHP.
