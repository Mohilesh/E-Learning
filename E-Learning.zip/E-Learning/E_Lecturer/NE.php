<?php 
  session_cache_limiter('public');
  session_start();
  $Id = $_SESSION['id'];
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">

<title>E-Learn</title>
	
	
	<!-- main css -->
	<link rel="stylesheet" href="../css/mystyle.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
  <link rel="stylesheet" href="fullcalendar/fullcalendar.min.css" />
  <script src="fullcalendar/lib/jquery.min.js"></script>
  <script src="fullcalendar/lib/moment.min.js"></script>
  <script src="fullcalendar/fullcalendar.min.js"></script>
	<style>
		.sidebar {
		background: #3a3a3f;
		margin-top: 70px;
		padding-top: 30px;
		position: fixed;
		left: 0;
		width: 250px;
		height: 100%;
		transition: 0.5s;
		transition-property: left;
		}
		header{
		position: fixed;
		background: #000000;
		padding: 20px;
		width: 100%;
		height: 30px;
		}

    body {
    
   
    font-size: 14px;
    font-family: "Lucida Grande", Helvetica, Arial, Verdana, sans-serif;
    }

    #calendar {
        width: 700px;
        margin: 0 auto;
    }

    .response {
        height: 60px;
    }

    .success {
        background: #cdf3cd;
        padding: 10px 60px;
        border: #c3e6c3 1px solid;
        display: inline-block;
    }

	</style>

  <script>

    $(document).ready(function () {
        var calendar = $('#calendar').fullCalendar({
            editable: true,
            events: "fetch-event.php",
            displayEventTime: false,
            eventRender: function (event, element, view) {
                if (event.allDay === 'true') {
                    event.allDay = true;
                } else {
                    event.allDay = false;
                }
            },
            selectable: true,
            selectHelper: true,
            select: function (start, end, allDay) {
                var title = prompt('Event Title:');

                if (title) {
                    var start = $.fullCalendar.formatDate(start, "Y-MM-DD HH:mm:ss");
                    var end = $.fullCalendar.formatDate(end, "Y-MM-DD HH:mm:ss");

                    $.ajax({
                        url: 'add-event.php',
                        data: 'title=' + title + '&start=' + start + '&end=' + end,
                        type: "POST",
                        success: function (data) {
                            displayMessage("Added Successfully");
                        }
                    });
                    calendar.fullCalendar('renderEvent',
                            {
                                title: title,
                                start: start,
                                end: end,
                                allDay: allDay
                            },
                    true
                            );
                }
                calendar.fullCalendar('unselect');
            },
            
            editable: true,
            eventDrop: function (event, delta) {
                        var start = $.fullCalendar.formatDate(event.start, "Y-MM-DD HH:mm:ss");
                        var end = $.fullCalendar.formatDate(event.end, "Y-MM-DD HH:mm:ss");
                        $.ajax({
                            url: 'edit-event.php',
                            data: 'title=' + event.title + '&start=' + start + '&end=' + end + '&id=' + event.id,
                            type: "POST",
                            success: function (response) {
                                displayMessage("Updated Successfully");
                            }
                        });
                    },
            eventClick: function (event) {
                var deleteMsg = confirm("Do you really want to delete?");
                if (deleteMsg) {
                    $.ajax({
                        type: "POST",
                        url: "delete-event.php",
                        data: "&id=" + event.id,
                        success: function (response) {
                            if(parseInt(response) > 0) {
                                $('#calendar').fullCalendar('removeEvents', event.id);
                                displayMessage("Deleted Successfully");
                            }
                        }
                    });
                }
            }

        });
    });

    function displayMessage(message) {
          $(".response").html("<div class='success'>"+message+"</div>");
        setInterval(function() { $(".success").fadeOut(); }, 1000);
    }
  </script>


</head>

<body class="studlogin">

    <input type="checkbox" id="check">
    <!--header area start-->
    <header>
      
      <div class="left_area">
        <h3>E<span>LEARN</span></h3>
      </div>
      <div class="right_area">
      <div align="center">Hi - <?php echo $_SESSION['username']; ?></div>
        <a href="../Logout.php" class="logout_btn">Logout</a>
      </div>
    </header>
    <!--header area end-->
    <!--sidebar start-->
    <div class="sidebar">
      <center>
        <h2>Lecturer</h2>
      </center>
      <a href="Lecturer_Home.php"><i class="fas fa-desktop"></i><span>Dashboard</span></a>
      <a href="Module.php"><i class="fas fa-sticky-note"></i><span>Module</span></a>
      <a href="Notes.php"><i class="fas fa-sticky-note"></i><span>Notes</span></a>
      <a href="Assignment.php"><i class="fas fa-sticky-note"></i><span>Assignment</span></a>
      <a href="Blog.php"><i class="fas fa-blog"></i><span>Blog</span></a>
      <a href="NE.php"><i class="fas fa-calendar-check"></i><span>Events</span></a>
      <a href="Chat/index.php"><i class="fas fa-comment-alt"></i><span>Chat</span></a>
    </div>
    <!--sidebar end-->

  <div class="content">
		<div class="ne" style="padding-top:100px;">
      <h2 style=" text-align: center;">Event Calendar</h2>

      <div class="response"></div>
      <div id='calendar'></div>

    </div>
	</div>

  </body>

</html>