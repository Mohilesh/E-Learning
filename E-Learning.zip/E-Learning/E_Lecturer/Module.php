<?php  
session_cache_limiter('public');
session_start();
$Id = $_SESSION['id'];
include("DB.php");
 $query ="SELECT * from user tbu inner join course tbc on tbu.courseid=tbc.courseid  inner join module tbm on tbc.courseid = tbm.courseid where tbu.userid = '$Id'" ;  
 $result = mysqli_query($db, $query);  
 ?> 
<!DOCTYPE html>  
 <html>  
      <head>  
           <title>E-Learn</title>  
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>  
           <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>            
           <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />  
      </head>  
      <body>  
           <br /><br />  
           <div class="container">  
                <h3 align="center">Module</h3>  
                <button id="myButton" align="right">Back</button>
                <br />  
                <div class="table-responsive">  
                     <table id="employee_data" class="table table-striped table-bordered">  
                          <thead>  
                               <tr>  
                                    <td>Module Name</td>  
                                    <td>Module Code</td>  
                                    <td>Module Mode</td>  
                          </thead>  
                          <?php  
                          while($row = mysqli_fetch_array($result))  
                          {  
                               echo '  
                               <tr>  
                                    <td>'.$row["moduleName"].'</td>  
                                    <td>'.$row["moduleCode"].'</td>  
                                    <td>'.$row["moduleMode"].'</td>    
                               </tr>  
                               ';  
                          }  
                          ?>  
                     </table>  
                </div>  
           </div>  
      </body>  
 </html>  
 <script>  
 $(document).ready(function(){  
      $('#employee_data').DataTable();  
 });  
 </script>  
 <script type="text/javascript">
    document.getElementById("myButton").onclick = function () {
        location.href = "NE.php";
    };
</script>