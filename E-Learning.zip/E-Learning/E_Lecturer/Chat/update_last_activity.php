<?php

//update_last_activity.php

include('database_connection.php');

session_start();

$query = "
UPDATE chat_details 
SET last_activity = now() 
WHERE chat_details_id = '".$_SESSION["chat_details_id"]."'
";

$statement = $connect->prepare($query);

$statement->execute();

?>

