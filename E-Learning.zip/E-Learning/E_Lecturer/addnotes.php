<?php
include('DB.php');

$video = "";
$module = "";
$lmid = "";

if ($_SERVER["REQUEST_METHOD"] == "POST")
  {
    
    if (isset($_POST['addnotes_btn'])&& isset($_FILES['bcfile'])) { // if save button on the form is clicked
	  // receive all input values from the form
    
	 $video = mysqli_real_escape_string($db, $_POST['video']);
    $lmid = mysqli_real_escape_string($db, $_POST['module']);

    $querymodule = "SELECT * FROM  lecturermodule where lmid = $lmid";
    $querymodule = mysqli_query($db, $querymodule);
    
     $querymodulerow = mysqli_fetch_assoc($querymodule) ;
    $module=$querymodulerow['moduleid'];



  

    if (($_FILES['bcfile']['name']!=""))
    {
    // Where the file is going to be stored
    $file = $_FILES['bcfile']['name'];
    $size = $_FILES['bcfile']['size'];
   
     $path = pathinfo($file);
     $filename = $path['filename'];
     $size= number_format($size);
     $temp_name = $_FILES['bcfile']['tmp_name'];
     $target_dir = "$destination/";
    }
    // Uploads files
    
    $destination = "../docs/notes/$module";
		
		if (!is_dir( $destination ) ) // If directory does not exist, create it.
		 {
			mkdir( "$destination" );
     }
     $querynotes="SELECT * FROM notes WHERE filename='$file'";
					$querynotes = mysqli_query($db, $querynotes);
					if(mysqli_num_rows($querynotes) > 0){
						header('location:Notes.php?msg=error');
					}else{
            $sql = "INSERT INTO notes (moduleid,lmid,videolink,filename,size) VALUES ('$module','$lmid','$video','$file','$size')";
     if (mysqli_query($db, $sql)) {
        
     
     
     
     $path_filename_ext = $target_dir.$file;
     move_uploaded_file($temp_name,$path_filename_ext);

     
     }
     header('location:Notes.php?msg=success');
    }      

            
        
    
  }
 
  }

    
    
    
    ?>
    
    
    
    
    

