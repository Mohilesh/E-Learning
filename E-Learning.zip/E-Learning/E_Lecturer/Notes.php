<?php 
session_cache_limiter('public');
session_start();
$Id = $_SESSION['id'];
  include('addnotes.php');
  $error = "";
  @$error=$_GET['msg'];
  if ($error=='success'){
    $error='<span style="color:green ; font-weight: bold;"> Successfully Added </span>';
  } elseif ($error=='error'){
 
    $error='<span style="color:red ; font-weight: bold;"> Already Added </span>';
  }
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">

<title>E-Learn</title>
	
	
	<!-- main css -->
	<link rel="stylesheet" href="../css/mystyle.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
  
</head>

<body class="studlogin">

    <input type="checkbox" id="check">
    <!--header area start-->
    <header>
      
      <div class="left_area">
        <h3>E<span>LEARN</span></h3>
      </div>
      <div class="right_area">
      <div align="center">Hi - <?php echo $_SESSION['username']; ?></div>
        <a href="../Logout.php" class="logout_btn">Logout</a>
      </div>
    </header>
    <!--header area end-->
    <!--sidebar start-->
    <div class="sidebar">
      <center>
        <h2>Lecturer</h2>
      </center>
      <a href="Lecturer_Home.php"><i class="fas fa-desktop"></i><span>Dashboard</span></a>
      <a href="Module.php"><i class="fas fa-sticky-note"></i><span>Module</span></a>
      <a href="Notes.php"><i class="fas fa-sticky-note"></i><span>Notes</span></a>
      <a href="Assignment.php"><i class="fas fa-sticky-note"></i><span>Assignment</span></a>
      <a href="Blog.php"><i class="fas fa-blog"></i><span>Blog</span></a>
      <a href="NE.php"><i class="fas fa-calendar-check"></i><span>Events</span></a>
      <a href="Chat/index.php"><i class="fas fa-comment-alt"></i><span>Chat</span></a>
    </div>
    <!--sidebar end-->

    <div class="content">
    <div class="notes" style="padding-top:100px"> 
    <div class="header">
            <h2>Add Notes</h2>
            <div  >
              <?php
                echo$error;
              ?>
            </div>
          </div>
        <form method="POST" action="addnotes.php" enctype="multipart/form-data">
          <div class="input-group">
                <label>Select Module</label>
                <select name="module" required id="module_type" >
                  <option value="0">Select Module</option>
                  <?php 
                          $querymodule = "SELECT * FROM  lecturermodule lm INNER JOIN module m on lm.moduleid = m.moduleid where lm.userid = $Id";
                          $querymodule = mysqli_query($db, $querymodule);
                          if(mysqli_num_rows($querymodule) > 0)
                          
                          {
                            while ($querymodulerow = mysqli_fetch_assoc($querymodule)) { ?>
                              <option value="<?php echo $querymodulerow['lmid']; ?>"><?php echo $querymodulerow['moduleCode']; ?></option>
                            <?php }
                          }
                          else
                          { ?>
                            <option value="0">No Module Found</option>
                          <?php }
                        ?>
                      </select>
              </div>
              
              <input type="file" name="bcfile" />
    
          <div class="input-group">
            <label>Video Link</label>
            <input type="text" name="video" required placeholder="Enter Video link">
          </div>
          <button type="submit" class="btn"  name="addnotes_btn" value="Upload">Add Notes</button>
          <button class="btn" id="myButton" align="right">View and Edit </button>
        </form>
      </div>


     

		
	  </div>

  </body>

</html>
<script type="text/javascript">
    document.getElementById("myButton").onclick = function () {
        location.href = "editnotes.php";
    };
</script>