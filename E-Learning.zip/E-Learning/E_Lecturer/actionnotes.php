<?php

//action.php

include('DB.php');

if($_POST['action'] == 'edit')
{
 $data = array(
  ':videolink'  => $_POST['videolink'],
  ':notesid'    => $_POST['notesid']
 );

 $query = "
 UPDATE notesid 
 SET videolink = :videolink,  
 WHERE notesid = :notesid
 ";
 $statement = $connect->prepare($query);
 $statement->execute($data);
 echo json_encode($_POST);
}

if($_POST['action'] == 'delete')
{
 $query = "
 DELETE FROM notes 
 WHERE notesid = '".$_POST["notesid"]."'
 ";
 $statement = $connect->prepare($query);
 $statement->execute();
 echo json_encode($_POST);
}


?>