<?php include('functions1.php') ?>
<!DOCTYPE html>
<html>
<head>
	<title>Registration Form</title>
	
	<link rel="stylesheet" href="css/mystyle.css">
</head>
<body>
<div class="header">
	<h2>Register</h2>
</div>
<form method="post" action="Register.php" class="register">
	<div  style= "colour:red">
	<?php
		echo'<span style="color:red ; font-weight: bold;">' .$error. '</span>';
	?>
	</div>
	<div class="input-group">
		<label>NIC/PASSPORT NO</label>
		<input type="text" name="nic" required placeholder="Enter NIC">
	</div>
	<div class="input-group">
			
			<label>Select Course</label>
			<select name="course" required id="course_type" >
				<option value="0">Select Course</option>
				<?php 
                $querycourse = "SELECT * FROM course ORDER BY courseid DESC";
                $querycourse = mysqli_query($db, $querycourse);
                if(mysqli_num_rows($querycourse) > 0)
                
                {
                  while ($querycourserow = mysqli_fetch_assoc($querycourse)) { ?>
                     <option value="<?php echo $querycourserow['courseid']; ?>"><?php echo $querycourserow['coursename']; ?></option>
                  <?php }
                }
                else
                { ?>
                  <option value="0">No Course Found</option>
                <?php }
               ?>
            </select>
		</div>
		<div class="input-group">
			<label>Year</label>
			<select name="year" required id="year" >
				<option value="0">Select Year</option>
				<option value="1">1</option>
				<option value="2">2</option>
				<option value="3">3</option>
			</select>
		</div>
	<div class="input-group">
		<label>Username</label>
		<input type="text" name="username" required placeholder="Enter UserName">
	</div>
	<div class="input-group">
		<label>Email</label>
		<input type="email" name="email" required placeholder="Enter Email">
	</div>
	<div class="input-group">
		<label>Password</label>
		<input type="password" required name="password" placeholder="Enter Password">
	</div>
	<div class="input-group">
		<button type="submit" class="btn"  name="register_btn">Register</button>
	</div>
	<p style="align:right">
		<a href="index.html">Back</a>
	</p>
	<p>
		Already a member? <a href="Login.php">Log in</a>
	</p>
</form>
</body>
</html>