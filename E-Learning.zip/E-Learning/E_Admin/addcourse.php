<?php
// initializing variables
$coursename = "";
$coursecode = "";
$errors = array(); 

// connect to the database
include('DB.php');

//Add New Course
if ($_SERVER["REQUEST_METHOD"] == "POST")
  {
	if (isset($_POST['addcourse_btn']))
	    { // ***********
	  // receive all input values from the form
	  $coursename = mysqli_real_escape_string($db, $_POST['coursename']);
	  $coursecode = mysqli_real_escape_string($db, $_POST['coursecode']);
    
	  if (!empty($_POST['coursename'])) { $coursename = mysqli_real_escape_string($db,trim($_POST['coursename']));}
	  if (!empty($_POST['coursecode'])) { $coursecode = mysqli_real_escape_string($db,trim($_POST['coursecode']));}

				if ($coursename != ''){
					$querycourse="SELECT * FROM course WHERE coursename='$coursename'";
					$querycourse = mysqli_query($db, $querycourse);
					if(mysqli_num_rows($querycourse) > 0){
						header('location:Course.php?msg=error');
					}else{
						// insert data in course
						$sql = "INSERT INTO `course`(coursename, coursecode)	
							VALUES ('".$coursename."', '".$coursecode."')";
						if (mysqli_query($db, $sql))
							{
								header('location:Course.php?msg=success');
							}
						
				}
			}
				
		}
	}




?>