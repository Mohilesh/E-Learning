<?php 
  session_cache_limiter('public');
  session_start();
  $Id = $_SESSION['id'];
  include('add.php');
  $error = "";
  @$error=$_GET['msg'];
  if ($error=='success'){
  $error= "Successfully Inserted";
  } 
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">

<title>E-Learn</title>
	
	
	<!-- main css -->
	<link rel="stylesheet" href="../css/mystyle.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">

	<style>
		.sidebar {
		background: #3a3a3f;
		margin-top: 70px;
		padding-top: 30px;
		position: fixed;
		left: 0;
		width: 250px;
		height: 100%;
		transition: 0.5s;
		transition-property: left;
		}
		header{
		position: fixed;
		background: #000000;
		padding: 20px;
		width: 100%;
		height: 30px;
		}

	</style>
</head>

<body class="studlogin">

    <input type="checkbox" id="check">
    <!--header area start-->
    <header>
      
      <div class="left_area">
        <h3>E<span>LEARN</span></h3>
      </div>
      <div class="right_area">
        <a href="../Logout.php" class="logout_btn">Logout</a>
      </div>
    </header>
    <!--header area end-->
    <!--sidebar start-->
    <div class="sidebar">
      <center>
        <h2>Admin Panel</h2>
      </center>
      <a href="Admin_Home.php"><i class="fas fa-desktop"></i><span>Dashboard</span></a>
      <a href="User.php"><i class="fas fa-user"></i><span>User</span></a>
      <a href="Course.php"><i class="fas fa-book-open"></i><span>Course</span></a>
      <a href="Module.php"><i class="fas fa-book-reader"></i><span>Module</span></a>
      <a href="LecturerModule.php"><i class="fas fa-book-reader"></i><span>Lecturer Module</span></a>
      <a href="NE.php"><i class="fas fa-calendar-check"></i><span>Events</span></a>
      <a href="Payment.php"><i class="fas fa-money-bill-wave"></i><span>Payment</span></a>
    </div>
    <!--sidebar end-->

    <div class="edituser">
        <div class="adduser" style="padding-top:60px;">
          <div class="header">
            <h2>Add New User</h2>
            <div  style= "colour:red">
              <?php
                echo'<span style="color:green ; font-weight: bold;">' .$error. '</span>';
              ?>
            </div>
          </div>
          <div>
            <form method="POST" action="add.php">
              <div class="input-group">
                <label>NIC</label>
                <input type="text" name="nic" required placeholder="Enter NIC">
              </div>
              <div class="input-group">
                <label>Username</label>
                <input type="text" name="username" required placeholder="Enter Username">
              </div>
              <div class="input-group">
                <label>Email</label>
                <input type="email" name="email" required placeholder="Enter Email">
              </div>
              <div class="input-group">
                <label>Password</label>
                <input type="password" required name="password" placeholder="Enter Password">
              </div>
              <div class="input-group">
              <label>Select Course</label>
              <select name="course" required id="course_type" >
                <option value="0">Select Course</option>
                <?php 
                        $querycourse = "SELECT * FROM course ORDER BY courseid DESC";
                        $querycourse = mysqli_query($db, $querycourse);
                        if(mysqli_num_rows($querycourse) > 0)
                        
                        {
                          while ($querycourserow = mysqli_fetch_assoc($querycourse)) { ?>
                            <option value="<?php echo $querycourserow['courseid']; ?>"><?php echo $querycourserow['coursename']; ?></option>
                          <?php }
                        }
                        else
                        { ?>
                          <option value="0">No Course Found</option>
                        <?php }
                      ?>
                    </select>
            </div>
              <div class="input-group">
                <label>User Type</label>
                <select name="user_type" required id="user_type" >
                  <option value="0">Select User Type</option>
                  <option value="A">Admin</option>
                  <option value="L">Lecturer</option>
                </select>
              </div>
              <button type="submit" class="btn"  name="add_btn">Add User</button>
              <button class="btn" id="myButton" align="right">View and Edit </button>
            </form>
          </div>
          
        
         
          
          
  <br />
  <br />
 </body>
</html>
<script type="text/javascript">
    document.getElementById("myButton").onclick = function () {
        location.href = "edituser.php";
    };
</script>


