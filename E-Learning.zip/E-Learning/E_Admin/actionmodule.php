<?php

//action.php

include('DB.php');

if($_POST['action'] == 'edit')
{
 $data = array(
  ':modulename'  => $_POST['moduelname'],
  ':modulecode'  => $_POST['modulecode'],
  ':modulemode'   => $_POST['modulemode'],
  ':year'   => $_POST['year'],
  ':moduleid'    => $_POST['moduleid']
 );

 $query = "
 UPDATE module 
 SET modulename = :modulename, 
 modulecode = :modulecode, 
 modulemode = :modulemode, 
 year = :year 
 WHERE moduleid = :moduleid
 ";
 $statement = $connect->prepare($query);
 $statement->execute($data);
 echo json_encode($_POST);
}

if($_POST['action'] == 'delete')
{
 $query = "
 DELETE FROM module 
 WHERE moduleid = '".$_POST["moduleid"]."'
 ";
 $statement = $connect->prepare($query);
 $statement->execute();
 echo json_encode($_POST);
}


?>