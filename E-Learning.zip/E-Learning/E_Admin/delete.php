<?php
	$id=$_GET['id'];
	include('DB.php');
	mysqli_query($db,"DELETE FROM user WHERE ID='$id'");
	header('location:User.php');
?>