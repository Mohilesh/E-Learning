<?php

//action.php

include('DB.php');

if($_POST['action'] == 'edit')
{
 $data = array(
  ':nic'  => $_POST['nic'],
  ':username'  => $_POST['username'],
  ':email'   => $_POST['email'],
  ':userid'    => $_POST['userid']
 );

 $query = "
 UPDATE user 
 SET nic = :nic, 
 username = :username, 
 email = :email 
 WHERE userid = :userid
 ";
 $statement = $connect->prepare($query);
 $statement->execute($data);
 echo json_encode($_POST);
}

if($_POST['action'] == 'delete')
{
 $query = "
 DELETE FROM user 
 WHERE userid = '".$_POST["userid"]."'
 ";
 $statement = $connect->prepare($query);
 $statement->execute();
 echo json_encode($_POST);
}


?>