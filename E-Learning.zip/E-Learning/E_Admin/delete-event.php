<?php
require_once "DB.php";

$NE_ID = $_POST['NE_ID'];
$sqlDelete = "DELETE from news_events WHERE NE_ID=".$NE_ID;

mysqli_query($db, $sqlDelete);
echo mysqli_affected_rows($db);

mysqli_close($db);
?>