<?php
	
	// connect to the database
	$db = mysqli_connect('localhost', 'root', '', 'e-learn');
	$connect = new PDO("mysql:host=localhost; dbname=e-learn", "root", "");
	
?>