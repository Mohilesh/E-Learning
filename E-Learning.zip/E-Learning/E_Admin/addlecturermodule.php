<?php
// initializing variables
$modulename = "";
$lecturer = "";

$errors = array(); 

// connect to the database
include('DB.php');

//Add New Module
if ($_SERVER["REQUEST_METHOD"] == "POST")
  {
	 
	if (isset($_POST['addlecturermodule_btn']))
		{ // ***********
			
	  // receive all input values from the form
	$modulename = mysqli_real_escape_string($db, $_POST['module']);
    $lecturer = mysqli_real_escape_string($db, $_POST['lecturer']);
    
	 	
		

				if ($modulename != ''){
					
					$querymodule="SELECT * FROM module WHERE moduleName='$modulename' ";
					$querymodule = mysqli_query($db, $querymodule);
					if(mysqli_num_rows($querymodule) > 0){
						
						header('location:lecturermodule.php?msg=error');
						
					}else{
						
						// insert data in course
						
						$sql = "INSERT INTO `lecturermodule`(userid, moduleid)	
							VALUES ('".$lecturer ."','".$modulename."')";
							
						if (mysqli_query($db, $sql))
						{
								
							header('location:lecturermodule.php?msg=success');
							
						}
				}
			}
		}
	}

?>