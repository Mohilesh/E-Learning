<?php
require_once "DB.php";

$NE_ID = $_POST['NE_ID'];
$eventName = $_POST['EventName'];
$eventTime = $_POST['EventTime'];
$description = $_POST['Description'];

$sqlUpdate = "UPDATE news_events SET EventName='" . $eventName . "',EventTime='" . $eventTime . "',Description='" . $description . "' WHERE NE_ID=" . $NE_ID;
mysqli_query($db, $sqlUpdate)
mysqli_close($db);

?>