<?php
// initializing variables
$nic = "";
$course = "";
$username = "";
$email    = "";
$user_type ="";
$errors = array(); 

// connect to the database
include('DB.php');

//Add New User
if ($_SERVER["REQUEST_METHOD"] == "POST")
  {
	if (isset($_POST['add_btn']))
	    { // ***********
	  // receive all input values from the form
    $nic = mysqli_real_escape_string($db, $_POST['nic']);
	$course = mysqli_real_escape_string($db, $_POST['course']);
    $username = mysqli_real_escape_string($db, $_POST['username']);
    $email = mysqli_real_escape_string($db, $_POST['email']);
    $password = mysqli_real_escape_string($db, $_POST['password']);
    $user_type = mysqli_real_escape_string($db, $_POST['user_type']);
	
			

				if ($nic != ''){
					$querynic="SELECT * FROM user WHERE nic='$nic'";
					$querynic = mysqli_query($db, $querynic);
					if(mysqli_num_rows($querynic) > 0){
						$error="NIC Already Registered";
					}else{
						// insert data in user
						$sql = "INSERT INTO `user`(nic, courseid, username, email, password, user_type)	
							VALUES ('".$nic."', '".$course ."', '".$username."', '".$email."', '".$password."', '".$user_type ."')";
						if (mysqli_query($db, $sql))
							{
								
								header('location:user.php?msg=success');
								
							}
					
				}
			}
		}
	}





	

?>