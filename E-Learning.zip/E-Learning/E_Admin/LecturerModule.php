<?php 
  session_cache_limiter('public');
  session_start();
  $Id = $_SESSION['id'];
  $error = "";
  include('addlecturermodule.php');
  @$error=$_GET['msg'];
  if ($error=='success'){
    $error='<span style="color:green ; font-weight: bold;"> Successfully Added </span>';
  } elseif ($error=='error'){
 
    $error='<span style="color:red ; font-weight: bold;"> Already Added </span>';
  }
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">

<title>E-Learn</title>
	
	
	<!-- main css -->
	<link rel="stylesheet" href="../css/mystyle.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
	<style>
		.sidebar {
		background: #3a3a3f;
		margin-top: 70px;
		padding-top: 30px;
		position: fixed;
		left: 0;
		width: 250px;
		height: 100%;
		transition: 0.5s;
		transition-property: left;
		}
		header{
		position: fixed;
		background: #000000;
		padding: 20px;
		width: 100%;
		height: 30px;
		}

	</style>
</head>

<body class="studlogin">

    <input type="checkbox" id="check">
    <!--header area start-->
    <header>
      
      <div class="left_area">
        <h3>E<span>LEARN</span></h3>
      </div>
      <div class="right_area">
        <a href="../Logout.php" class="logout_btn">Logout</a>
      </div>
    </header>
    <!--header area end-->
    <!--sidebar start-->
    <div class="sidebar">
      <center>
        <h2>Admin Panel</h2>
      </center>
      <a href="Admin_Home.php"><i class="fas fa-desktop"></i><span>Dashboard</span></a>
      <a href="User.php"><i class="fas fa-user"></i><span>User</span></a>
      <a href="Course.php"><i class="fas fa-book-open"></i><span>Course</span></a>
      <a href="Module.php"><i class="fas fa-book-reader"></i><span>Module</span></a>
      <a href="LecturerModule.php"><i class="fas fa-book-reader"></i><span>Lecturer Module</span></a>
      <a href="NE.php"><i class="fas fa-calendar-check"></i><span>Events</span></a>
      <a href="Payment.php"><i class="fas fa-money-bill-wave"></i><span>Payment</span></a>
    </div>
    <!--sidebar end-->

    <div class="content">

        <div class="module" style="padding-top:100px">
          <div class="header">
            <h2>Add Lecturer Module</h2>
            <div  >
              <?php
                echo$error;
              ?>
            </div>
          </div>
          <div>

            <form method="POST" action="addlecturermodule.php">
              <div class="input-group">
                <label>Select Module</label>
                <select name="module" required id="module" >
                  <option value="0">Select Module</option>
                  <?php 
                          $querylmodule = "SELECT * FROM module ORDER BY moduleid DESC";
                          $querylmodule = mysqli_query($db, $querylmodule);
                          if(mysqli_num_rows($querylmodule) > 0)
                          
                          {
                            while ($querylmodulerow = mysqli_fetch_assoc($querylmodule)) { ?>
                              <option value="<?php echo $querylmodulerow['moduleid']; ?>"><?php echo $querylmodulerow['moduleName']; ?></option>
                            <?php }
                          }
                          else
                          { ?>
                            <option value="0">No Module Found</option>
                          <?php }
                        ?>
                      </select>
              </div>
              <div class="input-group">
                <label>Select Lecturer</label>
                <select name="lecturer" required id="lecturer" >
                  <option value="0">Select Lecturer</option>
                  <?php 
                          $querylecturer = "SELECT * FROM user WHERE user_type='L' ";
                          $querylecturer = mysqli_query($db, $querylecturer);
                          if(mysqli_num_rows($querylecturer) > 0)
                          
                          {
                            while ($querylecturerrow = mysqli_fetch_assoc($querylecturer)) { ?>
                              <option value="<?php echo $querylecturerrow['userid']; ?>"><?php echo $querylecturerrow['username']; ?></option>
                            <?php }
                          }
                          else
                          { ?>
                            <option value="0">No User Found</option>
                          <?php }
                        ?>
                      </select>
              </div>

                
                
                <button type="submit" class="btn"  name="addlecturermodule_btn">Add Lecturer Module</button>
                
            </form>
          </div>



        
		
	</div>

  </body>

</html>
