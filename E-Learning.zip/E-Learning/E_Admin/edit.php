<?php 
  /*session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: Login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: Login.php");
  }*/
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">

<title>E-Learn</title>
	
	
	<!-- main css -->
	<link rel="stylesheet" href="../css/mystyle.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
	<style>
		.sidebar {
		background: #3a3a3f;
		margin-top: 70px;
		padding-top: 30px;
		position: fixed;
		left: 0;
		width: 250px;
		height: 100%;
		transition: 0.5s;
		transition-property: left;
		}
		header{
		position: fixed;
		background: #000000;
		padding: 20px;
		width: 100%;
		height: 30px;
		}

	</style>
</head>

<body class="studlogin">

    <input type="checkbox" id="check">
    <!--header area start-->
    <header>
      
      <div class="left_area">
        <h3>E<span>LEARN</span></h3>
      </div>
      <div class="right_area">
        <a href="Logout.php" class="logout_btn">Logout</a>
      </div>
    </header>
    <!--header area end-->
    <!--sidebar start-->
    <div class="sidebar">
      <center>
        <h2>Admin Panel</h2>
      </center>
      <a href="Student_Home.php"><i class="fas fa-desktop"></i><span>Dashboard</span></a>
      <a href="StudNote.php"><i class="fas fa-sticky-note"></i><span>Notes</span></a>
      <a href="#"><i class="fas fa-blog"></i><span>Blog</span></a>
      <a href="#"><i class="fas fa-calendar-check"></i><span>News & Events</span></a>
      <a href="#"><i class="fas fa-comment-alt"></i><span>Chat</span></a>
      <a href="#"><i class="fas fa-money-bill-wave"></i><span>Payment</span></a>
    </div>
    <!--sidebar end-->

    <div class="content">
    <div class="edituser">
        <div class="editcontent" style="padding-top:60px;">
          <div class="header">
            <h2>Edit User</h2>
          </div>
          <div>
            <form method="POST" action="update.php?id=<?php echo $id; ?>">
              <div class="input-group">
                <label>NIC</label>
                <input type="text" name="nic" required value="<?php echo $nic; ?>">
              </div>
              <div class="input-group">
                <label>Username</label>
                <input type="text" name="username" required value="<?php echo $username; ?>">
              </div>
              <div class="input-group">
                <label>Email</label>
                <input type="email" name="email" required value="<?php echo $email; ?>">
              </div>
              <div class="input-group">
                <label>Password</label>
                <input type="password" required name="password">
              </div>
              <div class="input-group">
                <label>Select Course</label>
                <select name="course" required id="course_type" >
                  <option value=""></option>
                  <option value="CS">Computer Science</option>
                  <option value="SE">Software Enginer</option>
                  <option value="TMS">Tourism Management</option>
                  <option value="BM">Pure Business Management</option>
                </select>
              </div>
              <div class="input-group">
                <label>User Type</label>
                <select name="user_type" required id="user_type" >
                  <option value=""></option>
                  <option value="Admin">Admin</option>
                  <option value="Lecturer">Lecturer</option>
                </select>
              </div>
              <button type="submit" class="btn"  name="update_btn">Update User</button>
            </form>
          </div>
	</div>

  </body>

</html>