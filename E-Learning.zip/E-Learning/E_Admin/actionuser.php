<?php

//action.php

include('DB.php');

if($_POST['action'] == 'edit')
{
 $data = array(
  ':nic'  => $_POST['nic'],
  ':year'  => $_POST['year'],
  ':username'  => $_POST['username'],
  ':email'   => $_POST['email'],
  ':password'  => $_POST['password'],
  ':user_type'  => $_POST['user_type'],
  ':userid'    => $_POST['userid']
 );

 $query = "
 UPDATE user 
 SET nic = :nic, 
 year = :year,
 username = :username,
 email = :email, 
 password = :password,
 user_type = :user_type
 WHERE userid = :userid
 ";
 $statement = $connect->prepare($query);
 $statement->execute($data);
 echo json_encode($_POST);
}

if($_POST['action'] == 'delete')
{
 $query = "
 DELETE FROM user 
 WHERE userid = '".$_POST["userid"]."'
 ";
 $statement = $connect->prepare($query);
 $statement->execute();
 echo json_encode($_POST);
}


?>