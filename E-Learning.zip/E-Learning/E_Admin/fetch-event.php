<?php
    require_once "DB.php";

    $json = array();
    $sqlQuery = "SELECT * FROM news_events ORDER BY NE_ID";

    $result = mysqli_query($db, $sqlQuery);
    $eventArray = array();
    while ($row = mysqli_fetch_assoc($result)) {
        array_push($eventArray, $row);
    }
    mysqli_free_result($result);

    mysqli_close($db);
    echo json_encode($eventArray);
?>