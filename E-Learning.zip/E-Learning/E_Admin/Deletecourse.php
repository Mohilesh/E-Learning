<?php
	$id=$_GET['id'];
	include('DB.php');
	mysqli_query($db,"DELETE FROM course WHERE ID='$id'");
	header('location:Course.php');
?>