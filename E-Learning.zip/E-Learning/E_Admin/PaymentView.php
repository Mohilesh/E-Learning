<?php 
  



  $connect = mysqli_connect("localhost", "root", "", "testing");  
  $query ="SELECT * FROM tbl_employee ORDER BY ID DESC";  
  $result = mysqli_query($connect, $query);  
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">

<title>E-Learn</title>
	
	
	<!-- main css -->
	<link rel="stylesheet" href="../css/mystyle.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
  <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>  
  <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>            
   <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />  
	<style>
		.sidebar {
		background: #3a3a3f;
		margin-top: 70px;
		padding-top: 30px;
		position: fixed;
		left: 0;
		width: 250px;
		height: 100%;
		transition: 0.5s;
		transition-property: left;
		}
		header{
		position: fixed;
		background: #000000;
		padding: 20px;
		width: 100%;
		height: 30px;
		}

	</style>
</head>

<body class="studlogin">

    <input type="checkbox" id="check">
    <!--header area start-->
    <header>
      
      <div class="left_area">
        <h3>E<span>LEARN</span></h3>
      </div>
      <div class="right_area">
        <a href="Logout.php" class="logout_btn">Logout</a>
      </div>
    </header>
    <!--header area end-->
    <!--sidebar start-->
    <div class="sidebar">
      <center>
        <h2>Admin Panel</h2>
      </center>
      <<a href="Admin_Home.php"><i class="fas fa-desktop"></i><span>Dashboard</span></a>
      <a href="Course.php"><i class="fas fa-sticky-note"></i><span>Course</span></a>
      <a href="Module.php"><i class="fas fa-blog"></i><span>Module</span></a>
      <a href="NE.php"><i class="fas fa-calendar-check"></i><span>News & Events</span></a>
      <a href="PaymentView.php"><i class="fas fa-money-bill-wave"></i><span>Payment</span></a>
    </div>
    <!--sidebar end-->

    <div class="content">
		<br /><br />  
           <div class="container">  
                <h3 align="center">Datatables Jquery Plugin with Php MySql and Bootstrap</h3>  
                <br />  
                <div class="table-responsive">  
                     <table id="employee_data" class="table table-striped table-bordered">  
                          <thead>  
                               <tr>  
                                    <td>Name</td>  
                                    <td>Address</td>  
                                    <td>Gender</td>  
                                    <td>Designation</td>  
                                    <td>Age</td>  
                               </tr>  
                          </thead>  
                          <?php  
                          while($row = mysqli_fetch_array($result))  
                          {  
                               echo '  
                               <tr>  
                                    <td>'.$row["name"].'</td>  
                                    <td>'.$row["address"].'</td>  
                                    <td>'.$row["gender"].'</td>  
                                    <td>'.$row["designation"].'</td>  
                                    <td>'.$row["age"].'</td>  
                               </tr>  
                               ';  
                          }  
                          ?>  
                     </table>  
                </div>  
           </div>  
	</div>

  </body>

</html>
$(document).ready(function(){  
      $('#employee_data').DataTable();  
 });  
 </script> 