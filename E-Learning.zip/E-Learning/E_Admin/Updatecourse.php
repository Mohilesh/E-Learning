<?php
	include('DB.php');
	$id=$_GET['id'];
	
	$coursename=$_POST['coursename'];
	$coursecode=$_POST['coursecode'];
	
	mysqli_query($db,"UPDATE course SET Coursename='$coursename', Coursecode='$coursecode' where id='$id'");
	header('location:Course.php');
?>