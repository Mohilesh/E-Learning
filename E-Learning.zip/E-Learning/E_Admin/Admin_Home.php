<?php 
  session_cache_limiter('public');
  session_start();
  $Id = $_SESSION['id'];
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">

<title>E-Learn</title>
	
	
	<!-- main css -->
	<link rel="stylesheet" href="../css/mystyle.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
	<style>
		.sidebar {
		background: #3a3a3f;
		margin-top: 70px;
		padding-top: 30px;
		position: fixed;
		left: 0;
		width: 250px;
		height: 100%;
		transition: 0.5s;
		transition-property: left;
		}
		header{
		position: fixed;
		background: #000000;
		padding: 20px;
		width: 100%;
		height: 30px;
		}

	</style>
</head>

<body class="studlogin">

    <input type="checkbox" id="check">
    <!--header area start-->
    <header>
      
      <div class="left_area">
        <h3>E<span>LEARN</span></h3>
      </div>
      <div class="right_area">
        <a href="../Logout.php" class="logout_btn">Logout</a>
      </div>
    </header>
    <!--header area end-->
    <!--sidebar start-->
    <div class="sidebar">
      <center>
        <h2>Admin Panel</h2>
      </center>
      <a href="Admin_Home.php"><i class="fas fa-desktop"></i><span>Dashboard</span></a>
      <a href="User.php"><i class="fas fa-user"></i><span>User</span></a>
      <a href="Course.php"><i class="fas fa-book-open"></i><span>Course</span></a>
      <a href="Module.php"><i class="fas fa-book-reader"></i><span>Module</span></a>
      <a href="LecturerModule.php"><i class="fas fa-book-reader"></i><span>Lecturer Module</span></a>
      <a href="NE.php"><i class="fas fa-calendar-check"></i><span>Events</span></a>
      <a href="Payment.php"><i class="fas fa-money-bill-wave"></i><span>Payment</span></a>
    </div>
    <!--sidebar end-->

    <div class="content">
		
            
        



	</div>

  </body>

</html>