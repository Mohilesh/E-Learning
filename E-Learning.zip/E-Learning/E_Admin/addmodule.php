<?php
// initializing variables
$modulename = "";
$modulecode = "";
$modulemode = "";
$year= "";
$course = "";
$errors = array(); 

// connect to the database
include('DB.php');

//Add New Module
if ($_SERVER["REQUEST_METHOD"] == "POST")
  {
	if (isset($_POST['addmodule_btn']))
	    { // ***********
	  // receive all input values from the form
	$course = mysqli_real_escape_string($db, $_POST['course']);
    $modulename = mysqli_real_escape_string($db, $_POST['modulename']);
    $modulecode = mysqli_real_escape_string($db, $_POST['modulecode']);
	$modulemode = mysqli_real_escape_string($db, $_POST['modulemode']);
	$year = mysqli_real_escape_string($db, $_POST['year']);
	 	
		

				if ($modulename != ''){
					$querymodule="SELECT * FROM module WHERE moduleName='$modulename' and courseid='$course'";
					$querymodule = mysqli_query($db, $querymodule);
					if(mysqli_num_rows($querymodule) > 0){
						header('location:module.php?msg=error');
						
					}else{
						// insert data in course
						
						$sql = "INSERT INTO `module`(moduleName, moduleCode, moduleMode, courseid, year )	
							VALUES ('".$modulename."', '".$modulecode ."', '".$modulemode ."' ,'".$course."','".$year ."')";
						if (mysqli_query($db, $sql))
						{
								
							header('location:module.php?msg=success');
							
						}
				}
			}
		}
	}

?>