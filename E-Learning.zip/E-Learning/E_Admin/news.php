<?php 
  /*session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: Login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: Login.php");
  }*/
  include('addnews.php');
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">

<title>E-Learn</title>
	
	
	<!-- main css -->
	<link rel="stylesheet" href="../css/mystyle.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
    <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>  
    <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>  
	<style>
		.sidebar {
		background: #3a3a3f;
		margin-top: 70px;
		padding-top: 30px;
		position: fixed;
		left: 0;
		width: 250px;
		height: 100%;
		transition: 0.5s;
		transition-property: left;
		}
		header{
		position: fixed;
		background: #000000;
		padding: 20px;
		width: 100%;
		height: 30px;
		}

	</style>
</head>

<body class="studlogin">

    <input type="checkbox" id="check">
    <!--header area start-->
    <header>
      
      <div class="left_area">
        <h3>E<span>LEARN</span></h3>
      </div>
      <div class="right_area">
        <a href="Logout.php" class="logout_btn">Logout</a>
      </div>
    </header>
    <!--header area end-->
    <!--sidebar start-->
    <div class="sidebar">
      <center>
        <h2>Admin Panel</h2>
      </center>
      <a href="Student_Home.php"><i class="fas fa-desktop"></i><span>Dashboard</span></a>
      <a href="StudNote.php"><i class="fas fa-sticky-note"></i><span>Notes</span></a>
      <a href="#"><i class="fas fa-blog"></i><span>Blog</span></a>
      <a href="#"><i class="fas fa-calendar-check"></i><span>News & Events</span></a>
      <a href="#"><i class="fas fa-comment-alt"></i><span>Chat</span></a>
      <a href="#"><i class="fas fa-money-bill-wave"></i><span>Payment</span></a>
    </div>
    <!--sidebar end-->

    <div class="content">
    <div class="news" style="padding-top:200px"> 
        <form method="POST" action="addnews.php">
          <div class="input-group">
            <label>News Title</label>
            <input type="text" name="newsntitle" required value="<?php echo $newstitle; ?>">
          </div>
          <div class="input-group">
            <label>Description</label>
            <input type="text" name="description" required value="<?php echo $description; ?>">
          </div>
          <button type="submit" class="btn"  name="addnews_btn">Add News</button>
        </form>
      </div>

    </div>
    
    <div class="col-md-9" >
                  
                <div class="table-responsive"  style="padding-left:250px">  
                     <table id="news" class="table table-striped table-bordered" >  
                          <thead>  
                               <tr>  
                                    <td>News Title</td>  
                                    <td>Description</td>  
                                      
                                    
                               </tr>  
                          </thead>  
                          <?php  
                          while($row = mysqli_fetch_assoc($result))  
                          {  ?>
                            <tr> 
                            
                              <td><?php echo $row['NewsName']; ?></td>
                              <td><?php echo $row['Description']; ?></td>
                             
                                
                                      
                               </tr>  
                               
                            <?php
                            }
                            ?>
                           
                     </table>  
                </div>  
            
        


      </div>

  </body>
  <script>  
 $(document).ready(function(){  
      $('#news').DataTable();  
 });  
 </script>
</html>