<?php
require_once "DB.php";

$eventName = isset($_POST['EventName']) ? $_POST['EventName'] : "";
$eventTime = isset($_POST['EventTime']) ? $_POST['EventTime'] : "";
$description = isset($_POST['Description']) ? $_POST['Description'] : "";

$sqlInsert = "INSERT INTO news_events (EventName,EventTime,Description) VALUES ('".$eventName."','".$eventTime."','".$description ."')";

$result = mysqli_query($db, $sqlInsert);

if (! $result) {
    $result = mysqli_error($db);
}
?>