<?php
	include('DB.php');
	$id=$_GET['id'];
	
	$firstname=$_POST['firstname'];
	$lastname=$_POST['lastname'];
	
	mysqli_query($db,"UPDATE user SET nic='$nic', username='$username', email='$email', password='$password', course='$course', user_type='$user_type', where id='$id'");
	header('location:user.php');
?>