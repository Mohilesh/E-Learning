<?php  
 $connect = mysqli_connect('localhost', 'root', '', 'e-learn');  
 $query ="SELECT * FROM payment ORDER BY paymentid DESC";  
 $result = mysqli_query($connect, $query);  
 ?>  
 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>E-Learn</title>  
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>  
           <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>            
           <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />  
      </head>  
      <body>  
           <br /><br />  
           <div class="container">  
                <h3 align="center">Data of Payment</br></h3>  
                <button class="btn" id="myButton" align="right">Back </button>
                <br />  
                <div class="table-responsive">  
                     <table id="employee_data" class="table table-striped table-bordered">  
                          <thead>  
                               <tr>  
                                    <td>ID</td>  
                                    <td>Year</td>  
                                    <td>Reference Code</td>  
                                    <td>Payment Mode</td>   
                               </tr>  
                          </thead>  
                          <?php  
                          while($row = mysqli_fetch_array($result))  
                          {  
                               echo '  
                               <tr>  
                                    <td>'.$row["paymentid"].'</td>  
                                    <td>'.$row["year"].'</td>  
                                    <td>'.$row["referenceCode"].'</td>  
                                    <td>'.$row["modePayment"].'</td>  
                               </tr>  
                               ';  
                          }  
                          ?>  
                     </table>  
                </div>  
           </div>  
      </body>  
 </html>  
 <script>  
 $(document).ready(function(){  
      $('#employee_data').DataTable();  
 });  
 </script> 
 </script>
<script type="text/javascript">
    document.getElementById("myButton").onclick = function () {
        location.href = "Admin_Home.php";
    };
</script>