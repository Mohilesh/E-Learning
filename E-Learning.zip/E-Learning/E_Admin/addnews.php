<?php
// initializing variables
$newstitle = "";
$description = "";
$errors = array(); 

// connect to the database
include('DB.php');


if ($_SERVER["REQUEST_METHOD"] == "POST")
  {
	if (isset($_POST['addnews_btn']))
	    { // ***********
	  // receive all input values from the form
    $newstitle = mysqli_real_escape_string($db, $_POST['newstitle']);
	$description = mysqli_real_escape_string($db, $_POST['description']);
	
		if (!empty($_POST['newstitle'])) { $newstitle = mysqli_real_escape_string($db,trim($_POST['newstitle']));}
		if (!empty($_POST['description'])) {$description = mysqli_real_escape_string($db,trim($_POST['description']));}
			

				if ($newstitle != ''){
						// insert data in course
						$sql = "INSERT INTO `news`(NewsName, Description)	
							VALUES ('".$newstitle."', '".$description ."', )";
						if (!mysqli_query($db, $sql))
							{
								//die('error inserting new record');
								die(mysqli_error($db));
							}
						else  // Insert successful
						  {
							// Store  id in session variable
						
							echo "Successfully Insert";
							header('location:news.php');
						}
				}
		}
	}

?>