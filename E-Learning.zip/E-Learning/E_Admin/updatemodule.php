<?php
	include('DB.php');
	$id=$_GET['id'];
	
	$modulename=$_POST['modulename'];
	$modulecode=$_POST['modulecode'];
	
	mysqli_query($db,"UPDATE module SET Modulename='$modulename', Modulecode='$modulecode' where id='$id'");
	header('location:Course.php');
?>