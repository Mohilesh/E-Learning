<?php

//action.php

include('DB.php');

if($_POST['action'] == 'edit')
{
 $data = array(
  ':coursename'  => $_POST['coursename'],
  ':coursecode'  => $_POST['coursecode'],
  ':courseid'    => $_POST['courseid']
 );

 $query = "
 UPDATE course 
 SET coursename = :coursename, 
 coursecode = :coursecode,  
 WHERE courseid = :courseid
 ";
 $statement = $connect->prepare($query);
 $statement->execute($data);
 echo json_encode($_POST);
}

if($_POST['action'] == 'delete')
{
 $query = "
 DELETE FROM course 
 WHERE courseid = '".$_POST["courseid"]."'
 ";
 $statement = $connect->prepare($query);
 $statement->execute();
 echo json_encode($_POST);
}


?>